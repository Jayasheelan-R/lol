import dropbox


dropbox_access_token= "sl.BKpufCFOQPQFpJnlIA8aeXhg5tXVvjyWfU1KhdnFRJaIaZ5JtgadYKrcvnZXRIssaJ7xpcWY3CeG2w6rMB5bB9YNHS9jmJ0h6V6ZhtIxCYphh8oIhf8YgwNwfJX82gez6eJXgL7ekvL2"    #Enter your own access token
dropbox_path= "/myapp76/wow.txt"
computer_path="lol.txt"

client = dropbox.Dropbox(dropbox_access_token)
print("[SUCCESS] dropbox account linked")


with open("lol2.txt", "wb") as f:
    metadata, res = client.files_download(path="/myapp76/wow.txt")
    f.write(res.content)